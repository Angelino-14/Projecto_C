#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#define MAX_TOKEN 1024
#define MAX_LINE 256



// Representação do tipo de token 
typedef enum { T_NUM, T_OP, T_LPAREN, T_RPAREN, T_INVALID } TokenType;

typedef struct {
    TokenType type;
    char escolh;  
    int value;
} Token;

typedef struct {
    Token data[MAX_TOKEN];
    int top;
} Stack;

void stack_init(Stack *s) { s->top = -1; }
int stack_empty(Stack *s) { return s->top < 0; }
void stack_push(Stack *s, Token t) { s->data[++s->top] = t; }
Token stack_pop(Stack *s) { return s->data[s->top--]; }
Token stack_peek(Stack *s) { return s->data[s->top]; }

// Precedência dos operadores
int prec(char escolh) {
    switch(escolh) {
        case '^': return 4;
        case '*': case '/': return 3;
        case '+': case '-': return 2;
    }
    return 0;
}
 // Se é operador e associatividade
int is_right_assoc(char escolh) { return escolh=='^'; }

// Representação de tokenizador simples
int tokenize(const char *s, Token tokens[], int *ntoks, char **err) {
    int i=0, n=0;
    while(s[i]) {
        if(isspace(s[i])) { i++; continue; }
        if(isdigit(s[i])) {
            tokens[n].type = T_NUM;
            tokens[n].value = s[i]-'0';
            n++; i++;
        } else if(strchr("+-*/^", s[i])) {
            tokens[n].type = T_OP;
            tokens[n].escolh = s[i];
            n++; i++;
        } else if(s[i]=='(') {
            tokens[n].type = T_LPAREN; n++; i++;
        } else if(s[i]==')') {
            tokens[n].type = T_RPAREN; n++; i++;
        } else {
            *err = "Caractere inválido";
            return -1;
        }
    }
    *ntoks = n;
    return 0;
}

// Converter infix → postfix (Shunting Yard)
int infix_to_postfix(Token infix[], int nin, Token postfix[], int *nout, char **err) {
    Stack st; stack_init(&st);
    int out = 0;
    for(int i=0;i<nin;i++){
        Token tk = infix[i];
        if(tk.type==T_NUM) {
            postfix[out++] = tk;
        } else if(tk.type==T_OP) {
            while(!stack_empty(&st)) {
                Token top = stack_peek(&st);
                if(top.type!=T_OP) break;
if( (prec(top.escolh) > prec(tk.escolh)) ||
                   (prec(top.escolh)==prec(tk.escolh) && !is_right_assoc(tk.escolh))) {
                    postfix[out++] = stack_pop(&st);
                } else break;
            }
            stack_push(&st, tk);
        } else if(tk.type==T_LPAREN) {
            stack_push(&st, tk);
        } else if(tk.type==T_RPAREN) {
            int found = 0;
            while(!stack_empty(&st)) {
                Token top = stack_pop(&st);
                if(top.type==T_LPAREN) { found=1; break; }
                postfix[out++] = top;
            }
            if(!found) { *err="Parênteses desbalanceados"; return -1; }
        }
    }
    while(!stack_empty(&st)) {
        Token top = stack_pop(&st);
        if(top.type==T_LPAREN || top.type==T_RPAREN) {
            *err="Parênteses desbalanceados"; return -1;
        }
        postfix[out++] = top;
    }
    *nout = out;
    return 0;
}

// Avaliar postfix
int evaluate_postfix(Token postfix[], int n, int *res, char **err) {
    Stack st; stack_init(&st);
    for(int i=0;i<n;i++){
        Token tk = postfix[i];
        if(tk.type==T_NUM) {
            stack_push(&st, tk);
        } else if(tk.type==T_OP) {
            if(st.top<1) { *err="Expressão malformada"; return -1; }
Token b = stack_pop(&st);
            Token a = stack_pop(&st);
            int av=a.value, bv=b.value;
            int val;
            switch(tk.escolh){
                case '+': val = av + bv; break;
                case '-': val = av - bv; break;
                case '*': val = av * bv; break;
                case '/':
                    if(bv==0){ *err="Divisão por zero"; return -1; }
                    val = av / bv; break;
                case '^': val = (int) pow(av, bv); break;
                default: *err="Operador desconhecido"; return -1;
            }
            Token t2 = {.type=T_NUM, .value=val};
            stack_push(&st, t2);
        } else {
            *err="Token inválido na avaliação"; return -1;
        }
    }
    if(st.top!=0) { *err="Expressão malformada"; return -1; }
    *res = stack_pop(&st).value;
    return 0;
}

int main(int argc, char **argv) {
    if(argc<2) {
        printf("Uso: %s in.txt\n", argv[0]);
        return 1;
    }
    FILE *fin = fopen(argv[1],"r");
    FILE *fout = fopen("out.txt","w");
    if(!fin||!fout) { perror("Erro ao abrir ficheiros"); return 1; }

    char line[MAX_LINE];
    while(fgets(line,MAX_LINE,fin)) {
        // Remove newline final
        line[strcspn(line,"\r\n")] = 0;
        char *err = NULL;
Token toks[MAX_TOKEN], pf[MAX_TOKEN];
        int ntoks=0, npf=0, result=0;

        if(tokenize(line, toks, &ntoks, &err)<0) {
            fprintf(fout, "Erro: %s\n", err);
            continue;
        }

        if(infix_to_postfix(toks, ntoks, pf, &npf, &err)<0) {
            fprintf(fout, "Erro: %s\n", err);
            continue;
        }

        if(evaluate_postfix(pf, npf, &result, &err)<0) {
            fprintf(fout, "Erro: %s\n", err);
            continue;
        }

        fprintf(fout, "%d\n", result);
    }

    fclose(fin);
    fclose(fout);
    return 0;
}

